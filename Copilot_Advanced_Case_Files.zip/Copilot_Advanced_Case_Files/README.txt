Microsoft Copilot (Advanced) - Case files only

One folder per module with the fictional case documents and data used in the labs.
Module 3 has no separate case files (its data is inside the exercise workbooks).
M12_Capstone includes copies of the Module 5 to 8 files needed for capstone options A and B (names start with "From_").
Upload files that agents use as knowledge to a lab SharePoint site before the labs.
All organisations, people and data are fictional. Do not upload client data to the lab tenant.
